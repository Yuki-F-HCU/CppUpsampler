//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: Pchip_upconvert.cpp
//
// MATLAB Coder version            : 3.3
// C/C++ source code generated on  : 15-Dec-2017 23:19:29
//

// Include Files
#include "rt_nonfinite.h"
#include "FIR_filtering.h"
#include "Linear_upconvert.h"
#include "Pchip_upconvert.h"
#include "Spline_upconvert.h"
#include "CppUpsampler_emxutil.h"
#include "interp1.h"

// Function Definitions

//
// Arguments    : const emxArray_real_T *music
//                double fs
//                double x
//                emxArray_real_T *music_x
//                double *fs_x
// Return Type  : void
//
void Pchip_upconvert(const emxArray_real_T *music, double fs, double x,
                     emxArray_real_T *music_x, double *fs_x)
{
  emxArray_real_T *y;
  double b_y;
  int k;
  double ndbl;
  double apnd;
  int absb;
  double cdiff;
  int n;
  emxInit_real_T(&y, 2);
  b_y = 1.0 / x;
  if (rtIsNaN(b_y)) {
    k = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = 1;
    emxEnsureCapacity((emxArray__common *)y, k, sizeof(double));
    y->data[0] = rtNaN;
  } else if ((b_y == 0.0) || ((1 < music->size[0]) && (b_y < 0.0)) ||
             ((music->size[0] < 1) && (b_y > 0.0))) {
    k = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = 0;
    emxEnsureCapacity((emxArray__common *)y, k, sizeof(double));
  } else if (rtIsInf(b_y)) {
    k = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = 1;
    emxEnsureCapacity((emxArray__common *)y, k, sizeof(double));
    y->data[0] = 1.0;
  } else if (std::floor(b_y) == b_y) {
    k = music->size[0];
    absb = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = (int)std::floor(((double)k - 1.0) / b_y) + 1;
    emxEnsureCapacity((emxArray__common *)y, absb, sizeof(double));
    absb = (int)std::floor(((double)k - 1.0) / b_y);
    for (k = 0; k <= absb; k++) {
      y->data[y->size[0] * k] = 1.0 + b_y * (double)k;
    }
  } else {
    ndbl = std::floor(((double)music->size[0] - 1.0) / b_y + 0.5);
    apnd = 1.0 + ndbl * b_y;
    if (b_y > 0.0) {
      cdiff = apnd - (double)music->size[0];
    } else {
      cdiff = (double)music->size[0] - apnd;
    }

    absb = music->size[0];
    if (1 > absb) {
      absb = 1;
    }

    if (std::abs(cdiff) < 4.4408920985006262E-16 * (double)absb) {
      ndbl++;
      apnd = music->size[0];
    } else if (cdiff > 0.0) {
      apnd = 1.0 + (ndbl - 1.0) * b_y;
    } else {
      ndbl++;
    }

    if (ndbl >= 0.0) {
      n = (int)ndbl;
    } else {
      n = 0;
    }

    k = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = n;
    emxEnsureCapacity((emxArray__common *)y, k, sizeof(double));
    if (n > 0) {
      y->data[0] = 1.0;
      if (n > 1) {
        y->data[n - 1] = apnd;
        absb = (n - 1) / 2;
        for (k = 1; k < absb; k++) {
          ndbl = (double)k * b_y;
          y->data[k] = 1.0 + ndbl;
          y->data[(n - k) - 1] = apnd - ndbl;
        }

        if (absb << 1 == n - 1) {
          y->data[absb] = (1.0 + apnd) / 2.0;
        } else {
          ndbl = (double)absb * b_y;
          y->data[absb] = 1.0 + ndbl;
          y->data[absb + 1] = apnd - ndbl;
        }
      }
    }
  }

  interp1(music, y, music_x);

  //  figure;
  //  plot(music);
  //  figure;
  //  plot(music_x);
  *fs_x = fs * x;
  emxFree_real_T(&y);
}

//
// File trailer for Pchip_upconvert.cpp
//
// [EOF]
//
