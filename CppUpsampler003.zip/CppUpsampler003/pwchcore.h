//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: pwchcore.h
//
// MATLAB Coder version            : 3.3
// C/C++ source code generated on  : 15-Dec-2017 23:19:29
//
#ifndef PWCHCORE_H
#define PWCHCORE_H

// Include Files
#include <cmath>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "CppUpsampler_types.h"

// Function Declarations
extern void b_pwchcore(const emxArray_real_T *x, const emxArray_real_T *y, int
  yoffset, const emxArray_real_T *s, const emxArray_real_T *dx, const
  emxArray_real_T *divdif, emxArray_real_T *pp_breaks, emxArray_real_T *pp_coefs);
extern void pwchcore(const emxArray_real_T *x, const emxArray_real_T *y, int
                     yoffset, const emxArray_real_T *s, emxArray_real_T
                     *pp_breaks, emxArray_real_T *pp_coefs);

#endif

//
// File trailer for pwchcore.h
//
// [EOF]
//
