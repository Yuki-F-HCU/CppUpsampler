//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: CppUpsampler_initialize.cpp
//
// MATLAB Coder version            : 3.3
// C/C++ source code generated on  : 15-Dec-2017 23:19:29
//

// Include Files
#include "rt_nonfinite.h"
#include "FIR_filtering.h"
#include "Linear_upconvert.h"
#include "Pchip_upconvert.h"
#include "Spline_upconvert.h"
#include "CppUpsampler_initialize.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void CppUpsampler_initialize()
{
  rt_InitInfAndNaN(8U);
}

//
// File trailer for CppUpsampler_initialize.cpp
//
// [EOF]
//
