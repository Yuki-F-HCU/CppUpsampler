//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: conv.cpp
//
// MATLAB Coder version            : 3.3
// C/C++ source code generated on  : 15-Dec-2017 23:19:29
//

// Include Files
#include "rt_nonfinite.h"
#include "FIR_filtering.h"
#include "Linear_upconvert.h"
#include "Pchip_upconvert.h"
#include "Spline_upconvert.h"
#include "conv.h"
#include "CppUpsampler_emxutil.h"

// Function Definitions

//
// Arguments    : const emxArray_real_T *A
//                const double B_data[]
//                const int B_size[2]
//                emxArray_real_T *C
// Return Type  : void
//
void conv(const emxArray_real_T *A, const double B_data[], const int B_size[2],
          emxArray_real_T *C)
{
  int nA;
  int nB;
  int nApnB;
  int k;
  nA = A->size[1];
  nB = B_size[1];
  nApnB = A->size[1] + B_size[1];
  if (A->size[1] == 0) {
  } else {
    nApnB--;
  }

  k = C->size[0] * C->size[1];
  C->size[0] = 1;
  C->size[1] = nApnB;
  emxEnsureCapacity((emxArray__common *)C, k, sizeof(double));
  for (k = 0; k < nApnB; k++) {
    C->data[k] = 0.0;
  }

  if (A->size[1] > 0) {
    if (B_size[1] > A->size[1]) {
      for (nApnB = 0; nApnB + 1 <= nA; nApnB++) {
        for (k = 0; k < nB; k++) {
          C->data[nApnB + k] += A->data[nApnB] * B_data[k];
        }
      }
    } else {
      for (nApnB = 0; nApnB + 1 <= nB; nApnB++) {
        for (k = 0; k < nA; k++) {
          C->data[nApnB + k] += B_data[nApnB] * A->data[k];
        }
      }
    }
  }
}

//
// File trailer for conv.cpp
//
// [EOF]
//
